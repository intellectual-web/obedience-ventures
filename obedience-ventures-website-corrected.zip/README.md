# OBEDIENCE VENTURES Website

Slogan: TESTED AND TRUSTED.

## Files
- `index.html` — website page
- `style.css` — styling and mobile layout
- `assets/obedience-ventures-logo.png` — business logo

## Publish with GitHub Pages
Upload the contents of this folder to the root of your repository, preserving the `assets` folder. Make sure `index.html` and `style.css` are at the repository root and the logo is at `assets/obedience-ventures-logo.png`. Then commit the changes and use Settings → Pages to publish from the `main` branch and `/ (root)`.

The site describes the business and its areas of focus confidently without guaranteeing that every product or service is immediately available. Contact the business to confirm current availability.
